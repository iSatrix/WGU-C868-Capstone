Title: Appointment Scheduler

Purpose of the application: To create and store customers and appointments in a database.

Author: Josh Shepherd

Contact Information: jshep76@wgu.edu

Application Version: QAM1

Date: 8-31-2021

IDE: NetBeans 8.2 with jdk1.8.0_111 and javafx-sdk-11.0.2

How to use the program: To login the user name and password are both "test".  The main screen will load upon successful login.  You may then use the various button to navigate the application. 

Description of the additional report:  My third report was to count how many total appointments are currently scheduled regardless of any limiters.  It is able to be viewed on the Main Menu.

MYSQL Connector: mysql-connector-java-5.1.23-bin.jar

